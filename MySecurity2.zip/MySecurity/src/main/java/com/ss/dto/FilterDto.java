package com.ss.dto;

public class FilterDto {

	
	Integer id;
	
	String name;
	
	String empCode;
	
	Integer companyId;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmpCode() {
		return empCode;
	}

	public void setEmpCode(String empCode) {
		this.empCode = empCode;
	}

	public Integer getCompanyId() {
		return companyId;
	}

	public void setCompanyId(Integer companyId) {
		this.companyId = companyId;
	}

	public FilterDto() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	
	
	
}
