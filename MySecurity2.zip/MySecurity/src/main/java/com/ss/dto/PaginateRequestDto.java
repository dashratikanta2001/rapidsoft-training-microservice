package com.ss.dto;

public class PaginateRequestDto {

	
	
	private Integer page;

	private Integer size;
	
	private String name;
	
	private String empCode;
	
	private EmployeeDto employee;

	public Integer getPage() {
		return page;
	}

	public void setPage(Integer page) {
		this.page = page;
	}

	public Integer getSize() {
		return size;
	}

	public void setSize(Integer size) {
		this.size = size;
	}
	
	

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmpCode() {
		return empCode;
	}

	public void setEmpCode(String empCode) {
		this.empCode = empCode;
	}

	public EmployeeDto getEmployee() {
		return employee;
	}

	public void setEmployee(EmployeeDto employee) {
		this.employee = employee;
	}

	public PaginateRequestDto() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
}
