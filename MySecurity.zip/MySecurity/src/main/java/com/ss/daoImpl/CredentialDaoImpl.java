package com.ss.daoImpl;

import javax.transaction.Transactional;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.ss.dao.CrediantialDao;
import com.ss.entity.CredentialMaster;



@Repository
@Transactional
public class CredentialDaoImpl  implements CrediantialDao{
	
	
	@Autowired
	private SessionFactory sessionFactory;

	@Override
	public Integer saveCrediantial(CredentialMaster credentialMaster) {
		try {
			sessionFactory.getCurrentSession().save(credentialMaster);
			return 1;

		} catch (Exception e) {
			return 0;
		}
	}

	public CredentialMaster getUsername(String username) {
		try { 
		Session session = sessionFactory.getCurrentSession();
			Criteria criteria = session.createCriteria(CredentialMaster.class);
			criteria.createAlias("employee", "e"); 
			criteria.add(Restrictions.eq("username", username));
			criteria.add(Restrictions.eq("e.isActive", true)); 

			return (CredentialMaster) criteria.uniqueResult();
		} catch (Exception e) {
		
			e.printStackTrace();
			return null; 
		}
	}

}
