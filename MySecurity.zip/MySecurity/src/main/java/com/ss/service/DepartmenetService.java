//package com.project.hrms.employee.service;
//
//import javax.validation.Valid;
//
//import com.project.hrms.employee.dto.DepartmentDto;
//import com.project.hrms.employee.response.Response;
//
//public interface DepartmenetService {
//
//	Response<?> saveDepartment(@Valid DepartmentDto departmentDto);
//
//}
