package com.ss.service;

public interface DesignationService {

}
