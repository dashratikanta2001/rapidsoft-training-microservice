package com.ss.dao;

import com.ss.entity.CredentialMaster;

public interface CrediantialDao {


	Integer saveCrediantial(CredentialMaster credentialMaster);

	CredentialMaster getUsername(String username);

}
