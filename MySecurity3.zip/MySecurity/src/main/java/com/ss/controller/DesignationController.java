package com.ss.controller;

public class DesignationController {

}
