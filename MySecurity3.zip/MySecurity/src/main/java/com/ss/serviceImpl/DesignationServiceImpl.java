package com.ss.serviceImpl;

import org.springframework.stereotype.Service;

import com.ss.service.DesignationService;
@Service
public class DesignationServiceImpl implements DesignationService{

}
